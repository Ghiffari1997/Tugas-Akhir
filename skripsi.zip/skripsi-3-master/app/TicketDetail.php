<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TicketDetail extends Model
{
    protected $table = 'ticket_detail';

    public function jenisGangguan()
    {
        return $this->hasOne('App\JenisGangguan', 'jenis_gangguan_id', 'jenis_gangguan_id');
    }
}
