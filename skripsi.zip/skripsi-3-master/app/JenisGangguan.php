<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JenisGangguan extends Model
{
    protected $table = 'jenis_gangguan';
    public $timestamps = false;

    public function kategoriGangguan()
    {
        return $this->belongsTo('App\KategoriGangguan', 'kategori_gangguan_id', 'kategori_gangguan_id');
    }
}
