<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StatusType extends Model
{
    protected $table = "status_type";
}
