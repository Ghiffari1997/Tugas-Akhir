<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    protected $table = 'ticket';

    public function customer()
    {
        return $this->hasOne('App\Customer', 'customer_id', 'customer_id');
    }

    public function ticketDetail()
    {
        return $this->hasMany('App\TicketDetail', 'ticket_id', 'ticket_id');
    }
    
    public function status()
    {
        return $this->hasOne('App\Status', 'status_id', 'ticket_status_id');
    }

    public function user()
    {
        return $this->hasOne('App\User', 'id', 'ticket_user_id');
    }

    public function kategoriGangguan()
    {
        return $this->hasOne('App\KategoriGangguan', 'kategori_gangguan_id', 'kategori_gangguan_id');
    }

    public function jenisGangguan()
    {
        return $this->hasOne('App\JenisGangguan', 'jenis_gangguan_id', 'jenis_gangguan_id');
    }
}
