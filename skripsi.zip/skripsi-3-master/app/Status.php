<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Status extends Model
{
    protected $table = "status";

    public function statusType()
    {
        return $this->hasOne('App\StatusType', 'status_id', 'status_id');
    }
}
