<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Customer;
use App\Helpers\FunctionsHelper;
use DB;

class CustomerController extends Controller
{
    public function __construct(Request $request)
    {
        $this->middleware(['auth']);
    }
    
    public function index()
    {
        $isRole = FunctionsHelper::checkRole('data-customer');
        $menuId = $isRole['menu_id'];
        $this->role = $isRole['status'];
        $dataRedis = FunctionsHelper::dataRedis();

        $customers = Customer::orderBy('customer_id', 'DESC')->get();
        return view('customer.index', compact('customers', 'menuId'));
    }

    public function editProfile($id)
    {
        $customer = Customer::where('customer_id', $id)->first();
        $dataUser = User::where('id', $id)->first();
        return view('customer.edit', compact('customer', 'dataUser'));
    }

    public function update(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            $paramUser['name'] = $request->customer_name;
            $paramUser['email'] = $request->customer_email;
            if ($request->customer_password != "") {
                $paramUser['password'] = FunctionsHelper::hashPassword($request->customer_password);
                $param['customer_password'] = FunctionsHelper::hashPassword($request->customer_password);
            }
            User::where('id', $id)->update($paramUser);

            $customer = Customer::where('customer_id', $id)->first();
            if (!empty($customer)) {
                $param['customer_name'] = $request->customer_name;
                $param['customer_email'] = $request->customer_email;
                $param['customer_phone_number'] = $request->customer_phone_number;
                $param['customer_internet_id'] = $request->customer_internet_id;
                $param['customer_address'] = $request->customer_address;
                Customer::where('customer_id', $id)->update($param);
            }
            DB::commit();

            return redirect()->back()->with('success', 'Data Profil berhasil diupdate.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()->with('error', $th->getMessage());
        }
    }
}
