<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Route;
use App\Helpers\FunctionsHelper;
use App\User;
use App\Role;
use Auth;
use Validator;
use URL;
use App\UserRole;
use DB;
use App\RoleMenu;
use App\Menu;
use App\RoleMenuAction;
use App\Action;

class RoleController extends Controller
{
    protected $role;

    public function __construct(Request $request)
    {
        $this->middleware(['auth']);
    }

    public function index()
    {
        $route = Route::current()->uri();
        $isRole = FunctionsHelper::checkRole($route);
        $menuId = $isRole['menu_id'];
        $this->role = $isRole['status'];
        $roles = Role::with(['roleMenu' => function($query) {
            $query->with('menu');
        }])->get();
        
        return view('role.index', compact('menuId', 'roles'));
    }

    public function create()
    {
        return view('role.create');
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255'
        ]);

        if ($validator->fails()) {
            return redirect('add-role')
                        ->withErrors($validator)
                        ->withInput();
        }
        
        DB::beginTransaction();
        try {

            $role = new Role();
            $role->roles_name = $request->name;
            $role->save();

            DB::commit();
            return redirect(URL::to('role'))->with('success', 'Role baru berhasil ditambahkan.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    public function edit($id)
    {
        $role = Role::where('roles_id', $id)->first();
        return view('role.edit', compact('role'));
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255'
        ]);

        if ($validator->fails()) {
            return redirect('role/edit/'.$id)
                        ->withErrors($validator)
                        ->withInput();
        }

        try {
            $data['roles_name'] = $request->name;
            Role::where('roles_id',$id)->update($data);

            return redirect(URL::to('role'))->with('success', 'Data berhasil diupdate.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    public function destroy($id)
    {
        try {
            Role::where('roles_id', $id)->delete();
            return redirect(URL::to('role'))->with('success', 'Data berhasil dihapus.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    public function access($id)
    {
        $route = Route::current()->uri();
        $isRole = FunctionsHelper::checkRole($route);
        $menuId = $isRole['menu_id'];
        $roleMenus = RoleMenu::with('menu')->where('roles_id', $id)->get();
        $menus = Menu::select(['menu_id', 'menu_name'])->get();
        $roleId = $id;
        
        return view('role.access', compact('menuId', 'menus', 'roleMenus', 'roleId'));
    }

    public function addAccess(Request $request)
    {
        try {
            $roleMenuData = RoleMenu::where('roles_id', $request->role_id)->first();
            if ($roleMenuData && $request->menu == null) {
                RoleMenu::where('roles_id', $request->role_id)->delete();
                return redirect(URL::to('role'))->with('success', 'Akes berhasil ditambahkan.');
            }

            if ($roleMenuData && $request->menu != null) {
                RoleMenu::where('roles_id', $request->role_id)->delete();
                self::saveData($request);
                return redirect(URL::to('role'))->with('success', 'Akes berhasil ditambahkan.');
            }

            if ($request->menu == null) {
                return redirect()->back()->withInput()->with('error', 'Tidak ada akses yang dipilih.');
            }
            self::saveData($request);
            
            return redirect(URL::to('role'))->with('success', 'Akes berhasil ditambahkan.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    private function saveData($request)
    {
        $data = [];
        foreach($request->menu as $menu => $item)
        {
            $data[] = [
                'roles_id' => $request->role_id,
                'menu_id' => $item,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ];
        }
        $roleMenu = new RoleMenu();
        $roleMenu->insert($data);
    }

    public function action($id)
    {
        $route = Route::current()->uri();
        $isRole = FunctionsHelper::checkRole($route);
        $menuId = $isRole['menu_id'];
        $split = explode('|', base64_decode($id));
        $roleId = $split[0];
        $menuId = $split[1];

        $roleAction = RoleMenuAction::select(['roles_id', 'menu_id', 'action_id'])
                        ->where('roles_id', $roleId)
                        ->where('menu_id', $menuId)
                        ->get();
        
        $actions = Action::select(['action_id', 'action_name'])->get();
        return view('role.action', compact('roleAction', 'actions', 'menuId', 'roleId', 'menuId'));
    }

    public function addAction(Request $request)
    {
        try {
            $roleAction = RoleMenuAction::where('roles_id', $request->roles_id)->where('menu_id', $request->menu_id)->first();
            if ($roleAction && $request->action == null) {
                RoleMenuAction::where('roles_id', $request->role_id)->where('menu_id', $request->menu_id)->delete();
                return redirect(URL::to('role'))->with('success', 'Akes berhasil ditambahkan.');
            }

            if ($roleAction && $request->action != null) {
                RoleMenuAction::where('roles_id', $request->role_id)->where('menu_id', $request->menu_id)->delete();
                self::saveAction($request);
                return redirect(URL::to('role'))->with('success', 'Akes berhasil ditambahkan.');
            }

            if ($request->action == null) {
                return redirect()->back()->withInput()->with('error', 'Tidak ada akses yang dipilih.');
            }
            self::saveAction($request);
            
            return redirect(URL::to('role'))->with('success', 'Akes berhasil ditambahkan.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    private function saveAction($request)
    {
        $param = [];
        foreach($request->action as $item)
        {
            $param[] = [
                'roles_id' => $request->roles_id,
                'menu_id' => $request->menu_id,
                'action_id' => $item
            ];
        }
        RoleMenuAction::insert($param);
    }
}
