<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Route;
use URL;
use App\Helpers\FunctionsHelper;
use App\KategoriGangguan;
use Validator;
use DB;

class DistruptionCategoryController extends Controller
{
    protected $role;

    public function __construct(Request $request)
    {
        $this->middleware(['auth']);
    }

    public function index()
    {
        $route = Route::current()->uri();
        $isRole = FunctionsHelper::checkRole($route);
        $menuId = $isRole['menu_id'];
        $this->role = $isRole['status'];
        $kategoriGangguan = KategoriGangguan::all();
        
        return view('kategori_gangguan.index', compact('menuId', 'kategoriGangguan'));
    }

    public function create()
    {
        return view('kategori_gangguan.create');
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'kategori_gangguan_name' => 'required|string|max:100'
        ]);

        if ($validator->fails()) {
            return redirect('add-kategori-gangguan')
                        ->withErrors($validator)
                        ->withInput();
        }
        
        DB::beginTransaction();
        try {

            $role = new KategoriGangguan();
            $role->kategori_gangguan_name = $request->kategori_gangguan_name;
            $role->save();

            DB::commit();
            return redirect(URL::to('kategori-gangguan'))->with('success', 'Role baru berhasil ditambahkan.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    public function edit($id)
    {
        $kategori = KategoriGangguan::where('kategori_gangguan_id', $id)->first();
        return view('kategori_gangguan.edit', compact('kategori'));
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'kategori_gangguan_name' => 'required|string|max:100'
        ]);

        if ($validator->fails()) {
            return redirect('kategori-gangguan/edit/'.$id)
                        ->withErrors($validator)
                        ->withInput();
        }

        try {
            $data['kategori_gangguan_name'] = $request->kategori_gangguan_name;
            KategoriGangguan::where('kategori_gangguan_id',$id)->update($data);

            return redirect(URL::to('kategori-gangguan'))->with('success', 'Data berhasil diupdate.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    public function destroy($id)
    {
        try {
            KategoriGangguan::where('kategori_gangguan_id', $id)->delete();
            return redirect(URL::to('kategori-gangguan'))->with('success', 'Data berhasil dihapus.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }
}
