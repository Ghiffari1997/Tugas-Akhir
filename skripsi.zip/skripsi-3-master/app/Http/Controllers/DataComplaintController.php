<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Route;
use App\Helpers\FunctionsHelper;
use DB;
use URL;
use Auth;
use App\Customer;
use App\Ticket;
use App\TicketDetail;
use App\User;
use App\Status;
use App\MapReview;
use Validator;

class DataComplaintController extends Controller
{
    protected $role;

    public function __construct(Request $request)
    {
        $this->middleware(['auth']);
    }

    public function index()
    {
        $route = Route::current()->uri();
        $isRole = FunctionsHelper::checkRole($route);
        $menuId = $isRole['menu_id'];
        $this->role = $isRole['status'];
        $dataRedis = FunctionsHelper::dataRedis();

        $ticket = Ticket::with('customer')
            ->with('status')
            ->with('user')
            ->with('kategoriGangguan')
            ->with('jenisGangguan')
            ->whereNotIn('ticket_status_id', [5]);

        if (strtoupper($dataRedis['role']['role_name']) == 'TEKNISI') {
            $ticket->where('ticket_user_id', $dataRedis['user_id']);
        }
        if (strtoupper($dataRedis['role']['role_name']) == "CUSTOMER") {
            $ticket->where('customer_id', $dataRedis['user_id']);
        }
        $tickets = $ticket->orderBy('ticket_score', 'desc')->get();

        return view('data_complaint.index', compact('menuId', 'tickets'));
    }

    public function edit($id)
    {
        $users = User::where('role_id', 4)->get();
        $status = Status::where('status_type_id', 1)->get();
        $ticket = Ticket::where('ticket_id', $id)->first();
        return view('data_complaint.edit', compact('ticket', 'users', 'status'));
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            //'ticket_user_id' => 'required'
        ]);

        if ($validator->fails()) {
            return redirect('data-komplain/edit/'.$id)
                ->withErrors($validator)
                ->withInput();
        }

        if (isset($request->ticket_user_id)) {
            $param['ticket_user_id'] = $request->ticket_user_id;
        }
        if (isset($request->ticket_status_id)) {
            $param['ticket_status_id'] = $request->ticket_status_id;
        }

        try {
            Ticket::where('ticket_id', $id)->update($param);

            return redirect('data-komplain')->with('success', 'Data berhasil diupdate');
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', $th->getMessage());
        }
    }

    public function report(Request $request)
    {
        $dataRedis = FunctionsHelper::dataRedis();
        $ticket = Ticket::orderBy('ticket_id', 'DESC');
        if (isset($request->month)) {
            $ticket->whereMonth('created_at', $request->month);
        }
        if (isset($request->status)) {
            $ticket->where('ticket_status_id', $request->status);
        }
        if (strtoupper($dataRedis['role']['role_name']) == 'TEKNISI') {
            $ticket->where('ticket_user_id', $dataRedis['user_id']);
        }
        if (strtoupper($dataRedis['role']['role_name']) == "CUSTOMER") {
            $ticket->where('customer_id', $dataRedis['user_id']);
        }
        $tickets = $ticket->get();

        return view('data_complaint.report', compact('tickets'));
    }

    public function filter(Request $request)
    {
        $param['month'] = $request->month;
        $param['status'] = $request->status;
        return redirect('report-komplain?'.http_build_query($param, '&'));
    }
}
