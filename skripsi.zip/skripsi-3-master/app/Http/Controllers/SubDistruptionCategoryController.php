<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Route;
use URL;
use App\Helpers\FunctionsHelper;
use App\KategoriGangguan;
use App\JenisGangguan;
use Validator;
use DB;

class SubDistruptionCategoryController extends Controller
{
    protected $role;

    public function __construct(Request $request)
    {
        $this->middleware(['auth']);
    }

    public function index()
    {
        $route = Route::current()->uri();
        $isRole = FunctionsHelper::checkRole($route);
        $menuId = $isRole['menu_id'];
        $this->role = $isRole['status'];
        $kategoriGangguan = JenisGangguan::with('kategoriGangguan')->get();
        
        return view('jenis_gangguan.index', compact('menuId', 'kategoriGangguan'));
    }

    public function create()
    {
        $kategoriGangguan = KategoriGangguan::all();
        return view('jenis_gangguan.create', compact('kategoriGangguan'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'kategori_gangguan_id' => 'required|numeric|max:100',
            'jenis_gangguan_name' => 'required|string|max:100',
            'prevalensi_value' => 'required|numeric|max:100',
            'seriousness_value' => 'required|numeric|max:100',
            'community_concern_value' => 'required|numeric|max:100',
            'manageability_value' => 'required|numeric|max:100',
        ]);

        if ($validator->fails()) {
            return redirect('add-jenis-gangguan')
                        ->withErrors($validator)
                        ->withInput();
        }
        
        DB::beginTransaction();
        try {

            $role = new JenisGangguan();
            $role->kategori_gangguan_id = $request->kategori_gangguan_id;
            $role->jenis_gangguan_name = $request->jenis_gangguan_name;
            $role->prevalensi_value = $request->prevalensi_value;
            $role->seriousness_value = $request->seriousness_value;
            $role->community_concern_value = $request->community_concern_value;
            $role->manageability_value = $request->manageability_value;
            $role->save();

            DB::commit();
            return redirect(URL::to('jenis-gangguan'))->with('success', 'Data baru berhasil ditambahkan.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    public function edit($id)
    {
        $kategoriGangguan = KategoriGangguan::all();
        $jenisGangguan = JenisGangguan::where('jenis_gangguan_id', $id)->first();
        
        return view('jenis_gangguan.edit', compact('kategoriGangguan', 'jenisGangguan'));
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'kategori_gangguan_id' => 'required|numeric|max:100',
            'jenis_gangguan_name' => 'required|string|max:100',
            'prevalensi_value' => 'required|numeric|max:100',
            'seriousness_value' => 'required|numeric|max:100',
            'community_concern_value' => 'required|numeric|max:100',
            'manageability_value' => 'required|numeric|max:100',
        ]);

        if ($validator->fails()) {
            return redirect('jenis-gangguan/edit/'.$id)
                        ->withErrors($validator)
                        ->withInput();
        }

        try {
            $data['kategori_gangguan_id'] = $request->kategori_gangguan_id;
            $data['jenis_gangguan_name'] = $request->jenis_gangguan_name;
            $data['prevalensi_value'] = $request->prevalensi_value;
            $data['seriousness_value'] = $request->seriousness_value;
            $data['community_concern_value'] = $request->community_concern_value;
            $data['manageability_value'] = $request->manageability_value;
            JenisGangguan::where('jenis_gangguan_id',$id)->update($data);

            return redirect(URL::to('jenis-gangguan'))->with('success', 'Data berhasil diupdate.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    public function destroy($id)
    {
        try {
            JenisGangguan::where('jenis_gangguan_id', $id)->delete();
            return redirect(URL::to('jenis-gangguan'))->with('success', 'Data berhasil dihapus.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }
}
