<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Helpers\FunctionsHelper;
use App\MapReview;
use Intervention\Image\Facades\Image;


class MapController extends Controller
{
    public function index()
    {
        $isRole = FunctionsHelper::checkRole('map-review');
        $menuId = $isRole['menu_id'];
        $maps = MapReview::orderBy('map_review_id', 'desc')->get();
        return view('map.index',compact('maps', 'menuId'));
    }

    public function add()
    {
        return view('map.create');
    }

    public function store(Request $request) 
    {
        try {
            $file = $request->file('map_review_image');
            $fileName = date('YmdHis') . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $canvas = Image::canvas('600', '400');
            $resizeThumbs  = Image::make($file)->resize('600', '400', function($constraint) {
                $constraint->aspectRatio();
            });
            $canvas->insert($resizeThumbs, 'center');
            $canvas->save(config('constants.IMAGE_PATH') . $fileName);

            $map = new MapReview();
            $map->map_review_name = $request->map_review_name;
            $map->map_review_image = $fileName;
            $map->save();
            return redirect('map-review')->with('success', 'Data berhasil ditambahkan');
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', $th->getMessage())->withInput();
        }
    }

    public function detail($id)
    {
        $map = MapReview::where('map_review_id', $id)->first();
        return view('map.detail', compact('map'));
    }

    public function delete($id)
    {
        try {
            MapReview::where('map_review_id', $id)->delete();
            return redirect('map-review')->with('success', 'Data berhasil ditambahkan');
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', $th->getMessage());
        }
    }
}
