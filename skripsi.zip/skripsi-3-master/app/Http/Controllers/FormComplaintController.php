<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use Route;
use App\Helpers\FunctionsHelper;
use App\Ticket;
use App\Customer;
use App\Status;
use App\User;
use App\KategoriGangguan;
use App\JenisGangguan;
use DB;

class FormComplaintController extends Controller
{
    protected $role;

    public function __construct(Request $request)
    {
        $this->middleware(['auth']);
    }

    public function index()
    {
        $route = Route::current()->uri();
        $isRole = FunctionsHelper::checkRole($route);
        $menuId = $isRole['menu_id'];
        $this->role = $isRole['status'];
        $users = User::where('role_id', 4)->get();
        $kategori = KategoriGangguan::all();
        $dataRedis = FunctionsHelper::dataRedis();
        $customer = [];
        if (strtoupper($dataRedis['role']['role_name']) == "CUSTOMER") {
            $customer = Customer::where('customer_id', $dataRedis['user_id'])->first();
        }

        return view('form_complaint.create', compact('users', 'kategori', 'customer'));
    }

    public function edit($id)
    {
        $users = User::where('role_id', 4)->get();
        $status = Status::where('status_type_id', 1)->get();
        $ticket = Ticket::where('ticket_id', $id)->first();
        return view('data_complaint.edit', compact('ticket', 'users', 'status'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'customer_name' => 'required|string|max:100',
            'customer_email' => 'required',
            'customer_address' => 'required',
            'kategori_gangguan_id' => 'required|numeric'
        ]);

        if ($validator->fails()) {
            return redirect('form-komplain-pelanggan')
                ->withErrors($validator)
                ->withInput();
        }

        DB::beginTransaction();
        try {
            $getCustomer = Customer::where('customer_internet_id', $request->customer_internet_id)->first();
            if (empty($getCustomer)) 
            {
                $dataRedis = FunctionsHelper::dataRedis();
                $customer = new Customer();
                if (strtoupper($dataRedis['role']['role_name']) == "CUSTOMER") {
                    $customer->customer_id = $dataRedis['user_id'];
                } else {
                    $user = new User();
                    $user->name = $request->customer_name;
                    $user->email = $request->customer_email;
                    $user->password = FunctionsHelper::hashPassword($request->customer_internet_id);
                    $user->status = 1;
                    $user->save();

                    $customer->customer_id = $user->id;
                }
                $customer->customer_name = $request->customer_name;
                $customer->customer_email = $request->customer_email;
                $customer->customer_password = FunctionsHelper::hashPassword($request->customer_internet_id);
                $customer->customer_internet_id = $request->customer_internet_id;
                $customer->customer_phone_number = $request->customer_phone_number;
                $customer->customer_address = $request->customer_address;
                $customer->save();
                $customerId = $customer->customer_id;
            } else {
                $customerId = $getCustomer->customer_id;
            }

            $jenisGangguan = JenisGangguan::where('kategori_gangguan_id', $request->kategori_gangguan_id)
                ->where('jenis_gangguan_id', $request->jenis_gangguan_id)->first();

            $ticketScore = ($jenisGangguan->prevalensi_value * $jenisGangguan->seriousness_value * $jenisGangguan->community_concern_value * $jenisGangguan->manageability_value);

            if ($ticketScore > 500) {
                $priority = 1;
            } 
            else if ($ticketScore >=300 && $ticketScore <= 500 )
            {
                $priority = 2;
            }
            else
            {
                $priority = 3;
            }

            $ticket = new Ticket();
            $ticket->customer_id = $customerId;
            $ticket->kategori_gangguan_id = $request->kategori_gangguan_id;
            $ticket->jenis_gangguan_id = $request->jenis_gangguan_id;
            $ticket->ticket_additional_info = $request->customer_addtional_info;
            $ticket->ticket_score = $ticketScore;
            $ticket->ticket_priority = $priority;
            $ticket->ticket_status_id = 4; // PENDING
            $ticket->ticket_user_id = $request->customer_user_id;
            $ticket->ticket_detail_complain = $request->detail_complain;
            $ticket->save();

            DB::commit();

            return redirect('data-komplain')->with('success', 'Data berhasil diupdate');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()->with('error', $th->getMessage())->withInput();
        }
    }

    public function getCustomer(Request $request)
    {
        $customer = Customer::where('customer_internet_id', $request->param)->first();
        if (empty($customer)) {
            return [
                'code' => 404,
                'data' => []
            ];
        }
        return [
            'code' => 200,
            'data' => $customer->toArray()
        ];
    }

    public function getJenisGangguan(Request $request)
    {
        $jenis = JenisGangguan::where('kategori_gangguan_id', $request->kategori_gangguan_id)->get();
        if (count($jenis) == 0) {
            return [
                'code' => 404,
                'data' => []
            ];
        }
        return [
            'code' => 200,
            'data' => $jenis->toArray()
        ];
    }
}
