<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redis;
use Auth;
use App\Helpers\FunctionsHelper;
use App\User;
use App\Ticket;
use App\Customer;
use Route;
use DB;

class HomeController extends Controller
{
    protected $isRole;
    public function __construct(Request $request)
    {
        $this->middleware(['auth']);
    }
    
    public function index()
    {
        // test pull
        $route = Route::current()->uri();
        $this->isRole = $isRole = FunctionsHelper::checkRole($route);
        $menuId = $this->isRole['menu_id'];
        $dataRedis = FunctionsHelper::dataRedis();

        if ($this->isRole['status'] == false) {
            return "Anda tidak mempunyai akses pada sistem ini.";
        }

        $ticket1 = DB::table('ticket')->where('ticket_status_id', 3);
        $ticket2 = DB::table('ticket')->where('ticket_status_id', 4);
        $ticket3 = DB::table('ticket')->where('ticket_status_id', 5);
        if (strtoupper($dataRedis['role']['role_name']) == 'TEKNISI') {
            $ticket1->where('ticket_user_id', $dataRedis['user_id']);
            $ticket2->where('ticket_user_id', $dataRedis['user_id']);
            $ticket3->where('ticket_user_id', $dataRedis['user_id']);
        }
        if (strtoupper($dataRedis['role']['role_name']) == 'CUSTOMER') {
            $ticket1->where('customer_id', $dataRedis['user_id']);
            $ticket2->where('customer_id', $dataRedis['user_id']);
            $ticket3->where('customer_id', $dataRedis['user_id']);
        }
        $onProgress = $ticket1->count();
        $pending = $ticket2->count();
        $done = $ticket3->count();

        return view('home.index', compact('menuId', 'onProgress', 'pending', 'done', 'customer'));
    }
}
