<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RoleMenuAction extends Model
{
    protected $table = 'role_menu_action';

    public function action()
    {
        return $this->hasOne('App\Action', 'action_id', 'action_id');
    }

}
