<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KategoriGangguan extends Model
{
    protected $table = 'kategori_gangguan';
    public $timestamps = false;

    public function jenisGangguan()
    {
        return $this->hasMany('App\JenisGangguan', 'kategori_gangguan_id', 'kategori_gangguan_id');
    }
}
