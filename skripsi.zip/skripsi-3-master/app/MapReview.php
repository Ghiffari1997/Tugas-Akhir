<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MapReview extends Model
{
    protected $table = 'map_review';
    protected $primaryKey = 'map_review_id';
}
