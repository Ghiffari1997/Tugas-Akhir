@extends('main_layout')
@section('content')

<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-12 col-12">
                    @if(session('success') || session('error'))
                        @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                            <span class="alert-text"><strong>Success!</strong> T{{session('success')}}</span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif
        
                        @if(session('error'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                            <span class="alert-text"><strong>Error!</strong> T{{session('error')}}</span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mt--6">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    {!! Form::model($dataUser, ['route' => ['data-customer.update', $dataUser->id], 'method' => 'put']) !!}
                        <div class="row">
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Nama</label>
                                    <input type="text" class="form-control" name="customer_name" id="customer_name" value="{{ $dataUser->name }}">
                                    @if ($errors->has('customer_name'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_name') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Email</label>
                                    <input type="text" class="form-control" name="customer_email" id="customer_email" value="{{ $dataUser->email }}">
                                    @if ($errors->has('customer_email'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_email') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Kata Sandi</label>
                                    <input type="text" class="form-control" name="customer_password" id="customer_password" value="{{ old('customer_password') }}">
                                    @if ($errors->has('customer_password'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_password') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        @if(!empty($customer))
                        <div class="row">
                            <div class="col-sm-12 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">No. Telp</label>
                                    <input type="text" class="form-control" name="customer_phone_number" id="customer_phone_number" value="{{ $customer->customer_phone_number }}">
                                    @if ($errors->has('customer_phone_number'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_phone_number') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">No. Internet</label>
                                    <input type="text" class="form-control" name="customer_internet_id" id="customer_internet_id" value="{{ $customer->customer_internet_id }}">
                                    @if ($errors->has('customer_internet_id'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_internet_id') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Alamat pelanggan</label>
                                    <textarea type="text" class="form-control" name="customer_address" id="customer_address">{{ $customer->customer_address }}</textarea>
                                    @if ($errors->has('customer_address'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_address') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        @endif
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <button class="btn btn-success notika-btn-success"><i class="notika-icon notika-sent"></i> Simpan</button>
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>

@endsection