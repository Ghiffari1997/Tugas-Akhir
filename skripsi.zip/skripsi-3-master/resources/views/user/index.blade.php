@extends('main_layout')
@section('content')

<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-12 col-12 text-right">
                    @if(FunctionsHelper::checkAction($menuId, 'create'))
                    <a href="{{ url('add-user') }}" class="btn btn-sm btn-neutral">Tambah baru</a>
                    @endif
                </div>

                @if(session('success') || session('error'))
                <div class="col-sm-12 col-md-12 col-lg-12">
                    @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show mt-2" role="alert">
                        <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                        <span class="alert-text"><strong>Success!</strong> {{session('success')}}</span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    @endif
                    @if(session('error'))
                    <div class="alert alert-danger alert-dismissible fade show mt-2" role="alert">
                        <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                        <span class="alert-text"><strong>danger!</strong> {{session('error')}}</span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    @endif
                </div>
                @endif
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mt--6">
    <div class="row">
        <div class="col">
            <div class="card">
                <!-- Card header -->
                <div class="card-header border-0">
                    <h3 class="mb-0">Data User</h3>
                </div>
                <!-- Light table -->
                <div class="table-responsive">
                    <table class="table align-items-center table-flush">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col" class="sort" data-sort="name">No.</th>
                                <th scope="col" class="sort" data-sort="budget">Nama Lengkap</th>
                                <th scope="col" class="sort" data-sort="status">Email</th>
                                <th scope="col">Status</th>
                                <th scope="col" class="sort" data-sort="completion">User Level</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            @foreach($users as $key => $user)
                            <tr>
                                <td>{{ $key+1 }}</td>
                                <td class="budget">{{ ucfirst($user->name) }}</td>
                                <td class="budget">{{ ucfirst($user->email) }}</td>
                                <td class="budget">{{ ($user->status == 1)?'Aktif':'Tidak Aktif' }}</td>
                                <td class="budget">{{ isset($user->role->roles_name)?ucfirst($user->role->roles_name):'' }}</td>
                                <td class="text-right">
                                    <div class="dropdown">
                                        <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                            @if(FunctionsHelper::checkAction($menuId, 'edit'))
                                            <a class="dropdown-item" href="{{ url('user/edit/'.$user->id) }}">Edit</a>
                                            @endif
                                            @if(FunctionsHelper::checkAction($menuId, 'delete'))
                                            <button data-href="{{ url('user/delete/'.$user->id) }}" class="dropdown-item" data-toggle="modal" data-target="#confirmationDelete" onclick="confirmationDelete(this)">Hapus</button>
                                            @endif
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="confirmationDelete" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body">
                <h2>Konfirmasi.</h2>
                <p>Apakah anda yakin ingin menghapus data ini ?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success agree-action" data-dismiss="modal">Yakin</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
    <script>
        function confirmationDelete(dom) {
            $(".agree-action").click(function () {
                window.location = dom.dataset.href;
            });
        }
    </script>
@endsection