@extends('main_layout')
@section('content')

<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-12 col-12">
                    @if(session('success') || session('error'))
                        @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                            <span class="alert-text"><strong>Success!</strong> T{{session('success')}}</span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif
        
                        @if(session('error'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                            <span class="alert-text"><strong>Error!</strong> T{{session('error')}}</span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mt--6">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <h3 class="mb-0">Form penambahan user.</h3>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    {!! Form::model($dataUser, ['route' => ['user.update', $dataUser->id], 'method' => 'PUT']) !!}
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Nama Lengkap</label>
                                    <input type="text" name="name" class="form-control" placeholder="Nama lengkap" value="{{ (old('name') !== null)?old('name'):$dataUser->name }}">
                                    @if ($errors->has('name'))
                                        <h6 class="text-red mt-2">{{ $errors->first('name') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-email">Alamat Email</label>
                                    <input type="text" name="email" class="form-control" placeholder="Alamat Email" value="{{ (old('name') !== null)?old('name'):$dataUser->email }}">
                                    @if ($errors->has('name'))
                                        <h6 class="text-red mt-2">{{ $errors->first('email') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-first-name">Kata Sandi</label>
                                    <input type="text" name="password" class="form-control" placeholder="Kata Sandi" value="{{ old('name') }}">
                                    @if ($errors->has('name'))
                                        <h6 class="text-red mt-2">{{ $errors->first('name') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-last-name">Role</label>
                                    <select class="form-control" name="role">
                                        <option value="">Silahkan pilih role <i>user</i></option>
                                        @foreach($roles as $role)
                                        <option value="{{$role->roles_id}}" {{ ($dataUser->role_id == $role->roles_id)?'selected':''}}>{{ucfirst($role->roles_name)}}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('role'))
                                        <h6 class="text-red mt-2">{{ $errors->first('name') }}</h6>
                                    @endif
                                </div>
                            </div>

                            <div class="col-lg-3">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-last-name">Role</label>
                                    <select class="form-control" name="status">
                                        <option value="1" {{($dataUser->status == 1)?'selected':''}}>Aktif</option>
                                        <option value="2" {{($dataUser->status == 2)?'selected':''}}>Tidak Aktif</option>
                                    </select>
                                    @if ($errors->has('role'))
                                        <h6 class="text-red mt-2">{{ $errors->first('name') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <a href="{{ url('user') }}" class="btn btn-danger notika-btn-danger"><i class="notika-icon notika-close"></i> Batal</a>
                                <button class="btn btn-success notika-btn-success"><i class="notika-icon notika-sent"></i> Simpan</button>
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>

@endsection