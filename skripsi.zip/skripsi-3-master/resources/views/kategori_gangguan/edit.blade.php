@extends('main_layout')
@section('content')

<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-12 col-12">
                    @if(session('success') || session('error'))
                        @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                            <span class="alert-text"><strong>Success!</strong> T{{session('success')}}</span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif
        
                        @if(session('error'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                            <span class="alert-text"><strong>Error!</strong> T{{session('error')}}</span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mt--6">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <h3 class="mb-0">Form edit kategori gangguan.</h3>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    {!! Form::model($kategori, ['route' => ['kategori-gangguan.update', $kategori->kategori_gangguan_id], 'method' => 'put']) !!}
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Kategori Gangguan</label>
                                    <input type="text" name="kategori_gangguan_name" class="form-control" placeholder="Kategori Gangguan" value="{{ $kategori->kategori_gangguan_name }}">
                                    @if ($errors->has('kategori_gangguan_name'))
                                        <h6 class="text-red mt-2">{{ $errors->first('kategori_gangguan_name') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <a href="{{ url('kategori-gangguan') }}" class="btn btn-danger notika-btn-danger"><i class="notika-icon notika-close"></i> Batal</a>
                                <button class="btn btn-success notika-btn-success"><i class="notika-icon notika-sent"></i> Simpan</button>
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>

@endsection