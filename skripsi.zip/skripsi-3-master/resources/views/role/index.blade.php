@extends('main_layout')
@section('content')

<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-12 col-12 text-right">
                    @if(FunctionsHelper::checkAction($menuId, 'create'))
                    <a href="{{ url('add-role') }}" class="btn btn-sm btn-neutral">Tambah baru</a>
                    @endif
                </div>

                @if(session('success') || session('error'))
                <div class="col-sm-12 col-md-12 col-lg-12">
                    @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show mt-2" role="alert">
                        <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                        <span class="alert-text"><strong>Success!</strong> {{session('success')}}</span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    @endif
                    @if(session('error'))
                    <div class="alert alert-danger alert-dismissible fade show mt-2" role="alert">
                        <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                        <span class="alert-text"><strong>danger!</strong> {{session('error')}}</span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    @endif
                </div>
                @endif
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mt--6">
    <div class="row">
        <div class="col">
            <div class="card">
                <!-- Card header -->
                <div class="card-header border-0">
                    <h3 class="mb-0">Data User</h3>
                </div>
                <!-- Light table -->
                <div class="table-responsive">
                    <table class="table align-items-center table-flush">
                        <thead class="thead-light">
                            <tr>
                                <th>No.</th>
                                <th>User Level</th>
                                <th>Akses</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            @foreach($roles as $key => $role)
                                <tr>
                                    <td>{{$key+1}}</td>
                                    <td>{{ucfirst($role->roles_name)}}</td>
                                    <td>
                                        <ul>
                                            @foreach($role->roleMenu as $menu)
                                                <li><a href="{{ ($menu->menu->parent_id == null)?'#':URL::to('role/action/'.base64_encode($role->roles_id.'|'.$menu->menu->menu_id)) }}">{{ $menu->menu->menu_name }}</a></li>
                                            @endforeach
                                        </ul>
                                    </td>
                                    <td>
                                        @if(FunctionsHelper::checkAction($menuId, 'edit'))
                                        <a class="btn btn-sm btn-primary my-4" href="{{ URL::to('role/edit/'.$role->roles_id) }}">Edit</a>
                                        @endif
                                        @if(FunctionsHelper::checkAction($menuId, 'delete'))
                                        <button data-href="{{ URL::to('role/delete/'.$role->roles_id) }}" class="btn btn-sm btn-danger my-4" data-toggle="modal" data-target="#confirmationDelete" onclick="confirmationDelete(this)">Hapus</button>
                                        @endif
                                        <a href="{{ URL::to('role/access/'.$role->roles_id) }}" class="btn btn-sm btn-success my-4">Akses</i></a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="confirmationDelete" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body">
                <h2>Konfirmasi.</h2>
                <p>Apakah anda yakin ingin menghapus data ini ?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success agree-action" data-dismiss="modal">Yakin</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
    <script>
        function confirmationDelete(dom) {
            $(".agree-action").click(function () {
                window.location = dom.dataset.href;
            });
        }
    </script>
@endsection