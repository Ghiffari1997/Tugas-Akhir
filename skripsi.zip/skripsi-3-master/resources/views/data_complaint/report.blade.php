@extends('main_layout')
@section('content')

<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-12 col-12 text-right">
                    {{-- @if(FunctionsHelper::checkAction($menuId, 'create'))
                    <a href="{{ url('add-jenis-gangguan') }}" class="btn btn-sm btn-neutral">Tambah baru</a>
                    @endif --}}
                </div>

                @if(session('success') || session('error'))
                <div class="col-sm-12 col-md-12 col-lg-12">
                    @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show mt-2" role="alert">
                        <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                        <span class="alert-text"><strong>Success!</strong> {{session('success')}}</span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    @endif
                    @if(session('error'))
                    <div class="alert alert-danger alert-dismissible fade show mt-2" role="alert">
                        <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                        <span class="alert-text"><strong>danger!</strong> {{session('error')}}</span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    @endif
                </div>
                @endif
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mt--6">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <h3 class="mb-0">Report Komplain.</h3>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    {!! Form::open(['url' => 'report-komplain/filter', 'method' => 'post']) !!}
                        <div class="row">
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Bulan</label>
                                    <select name="month" id="" class="form-control">
                                        <option value="">Semua</option>
                                        <option value="1">Januari</option>
                                        <option value="2">Februari</option>
                                        <option value="3">Maret</option>
                                        <option value="4">April</option>
                                        <option value="5">Mei</option>
                                        <option value="6">Juni</option>
                                        <option value="7">Juli</option>
                                        <option value="8">Agustus</option>
                                        <option value="9">September</option>
                                        <option value="10">Oktober</option>
                                        <option value="11">November</option>
                                        <option value="12">Desember</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Status</label>
                                    <select name="status" id="" class="form-control">
                                        <option value="">Semua</option>
                                        <option value="3">On Progress</option>
                                        <option value="4">Pending</option>
                                        <option value="5">Close/Done</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">&nbsp;</label>
                                    <button type="submit" class="btn btn-success form-control" id="search-customer">Filter</button>
                                </div>
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mt-0">
    <div class="row">
        <div class="col">
            <div class="card">
                <!-- Card header -->
                <div class="card-header border-0">
                    <h3 class="mb-0">Data Komplain</h3>
                </div>
                <!-- Light table -->
                <div class="table-responsive">
                    <table class="table align-items-center table-flush">
                        <thead class="thead-light">
                            <tr>
                                <th>No.</th>
                                {{-- <th>Kode</th> --}}
                                <th>Status</th>
                                <th>Pelanggan</th>
                                <th>No. Internet</th>
                                <th>No. Telp</th>
                                {{-- <th>Alamat</th> --}}
                                {{-- <th>Info Tambahan</th> --}}
                                <th>Prioritas</th>
                                <th>Score</th>
                                
                                <th>Teknisi</th>
                                <th>Kategori Gangguan</th>
                                <th>Jenis Gangguan</th>
                                {{-- <th scope="col">Aksi</th> --}}
                            </tr>
                        </thead>
                        <tbody class="list">
                            @foreach($tickets as $key => $item)
                            <tr>
                                <td>{{ $key+1 }}</td>
                                {{-- <td>
                                    @if ($item->ticket_priority == 1)
                                    <button class="btn btn-md btn-danger"></button>
                                    @elseif($item->ticket_priority = 2)
                                    <button class="btn btn-md btn-default" style="background: yellow"></button>
                                    @else
                                    <button class="btn btn-md btn-success"></button>
                                    @endif
                                </td> --}}
                                <td>{{ $item->status->status_name }}</td>
                                <td>{{ $item->customer->customer_name }}</td>
                                <td>{{ $item->customer->customer_internet_id }}</td>
                                <td>{{ $item->customer->customer_phone_number }}</td>
                                {{-- <td>{{ $item->customer->customer_address }}</td> --}}
                                {{-- <td>{{ $item->ticket_additional_info }}</td> --}}
                                <td>{{ $item->ticket_priority }}</td>
                                <td>{{ $item->ticket_score }}</td>
                                
                                <td>{{ isset($item->user->name)?$item->user->name:'' }}</td>
                                <td>{{ $item->kategoriGangguan->kategori_gangguan_name }}</td>
                                <td>
                                    {{ $item->jenisGangguan->jenis_gangguan_name }}
                                </td>
                                {{-- <td> --}}
                                    {{-- @if(FunctionsHelper::checkAction($menuId, 'edit'))
                                    <a href="{{ url('data-komplain/edit/'.$item->ticket_id) }}" class="btn btn-sm btn-primary">Edit</a>
                                    @endif --}}
                                {{-- </td> --}}
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="confirmationDelete" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body">
                <h2>Konfirmasi.</h2>
                <p>Apakah anda yakin ingin menghapus data ini ?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success agree-action" data-dismiss="modal">Yakin</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
    <script>
        function confirmationDelete(dom) {
            $(".agree-action").click(function () {
                window.location = dom.dataset.href;
            });
        }
    </script>
@endsection