@extends('main_layout')
@section('content')

<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-12 col-12">
                    @if(session('success') || session('error'))
                        @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                            <span class="alert-text"><strong>Success!</strong> {{session('success')}}</span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif
        
                        @if(session('error'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                            <span class="alert-text"><strong>Error!</strong> {{session('error')}}</span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mt--6">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <h3 class="mb-0">Form update data komplain.</h3>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    {!! Form::model($ticket, ['route' => ['data-komplain.update', $ticket->ticket_id], 'method' => 'put']) !!}
                        <div class="row">

                            @if (strtolower($user['role']['role_name']) == 'helpdesk')
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Teknisi</label>
                                    <select name="ticket_user_id" class="form-control">
                                        @foreach($users as $item)
                                            <option value="{{ $item->id }}" {{ ($item->id == $ticket->ticket_user_id)?"selected":"" }}>{{ $item->name }}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('ticket_user_id'))
                                        <h6 class="text-red mt-2">{{ $errors->first('ticket_user_id') }}</h6>
                                    @endif
                                </div>
                            </div>
                            @endif
                            
                            @if (strtolower($user['role']['role_name']) == 'teknisi')
                            <div class="col-sm-12 col-md-8 col-lg-8">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Status Gangguan</label>
                                    <select name="ticket_status_id" class="form-control">
                                        <option value="">Silahkan Pilih Status Pengerjaan</option>
                                        @foreach($status as $item)
                                            <option value="{{ $item->status_id }}" {{ ($item->status_id == $ticket->ticket_status_id)?"selected":"" }}>{{ $item->status_name }}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('ticket_status_id'))
                                        <h6 class="text-red mt-2">{{ $errors->first('ticket_status_id') }}</h6>
                                    @endif
                                </div>
                            </div>
                            @endif
                        </div>
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <a href="{{ url('data-komplain') }}" class="btn btn-danger notika-btn-danger"><i class="notika-icon notika-close"></i> Batal</a>
                                <button class="btn btn-success notika-btn-success"><i class="notika-icon notika-sent"></i> Simpan</button>
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>

@endsection