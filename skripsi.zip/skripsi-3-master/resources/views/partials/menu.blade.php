<nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
        <!-- Brand -->
        <div class="sidenav-header  align-items-center">
            <a class="navbar-brand" href="{{ url('home') }}">
            <img src="{{ URL::asset('assets/img/brand/logo_ta.png') }}" class="navbar-brand-img" alt="..."  style="max-height: 5rem">
            </a>
        </div>
        <div class="navbar-inner">
            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="sidenav-collapse-main">

                @if(isset($user['role']['menu']))
                @foreach($user['role']['menu'] as $key => $role)

                @if(count($role['sub_menu']) > 0)
                <h6 class="navbar-heading p-0 text-muted mt-3">
                    <span class="docs-normal">{{ ucfirst($role['menu_name']) }}</span>
                </h6>
                @foreach($role['sub_menu'] as $item)
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="{{ URL::to('/'.$item['menu_url']) }}">
                            {!! $item['menu_icon'] !!}
                        <span class="nav-link-text">{{ ucfirst($item['menu_name']) }}</span>
                        </a>
                    </li>
                </ul>
                @endforeach
                @else
                <!-- Nav items -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" href="{{ URL::to('/'.$role['menu_url']) }}">
                        {!! $role['menu_icon'] !!}
                        <span class="nav-link-text">{{ ucfirst($role['menu_name']) }}</span>
                        </a>
                    </li>
                </ul>
                @endif

                @endforeach
                

                @endif
            </div>
        </div>
    </div>
  </nav>

