@extends('main_layout')
@section('content')

<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-12 col-12">
                    @if(session('success') || session('error'))
                        @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                            <span class="alert-text"><strong>Success!</strong> T{{session('success')}}</span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif
        
                        @if(session('error'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                            <span class="alert-text"><strong>Error!</strong> T{{session('error')}}</span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mt--6">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <h3 class="mb-0">Form edit jenis gangguan.</h3>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    {!! Form::model($jenisGangguan, ['route' => ['jenis-gangguan.update', $jenisGangguan->jenis_gangguan_id], 'method' => 'put']) !!}
                        <div class="row">
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Kategori Gangguan</label>
                                    <select name="kategori_gangguan_id" class="form-control">
                                        <option value="">Silahkan Pilih Kategori Gangguan</option>
                                        @foreach($kategoriGangguan as $item)
                                            <option value="{{ $item->kategori_gangguan_id }}" {{ ($item->kategori_gangguan_id == $jenisGangguan->kategori_gangguan_id)?"selected":"" }}>{{ $item->kategori_gangguan_name }}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('kategori_gangguan_id'))
                                        <h6 class="text-red mt-2">{{ $errors->first('kategori_gangguan_id') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-8 col-lg-8">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Jenis Gangguan</label>
                                    <input type="text" name="jenis_gangguan_name" class="form-control" placeholder="Jenis Gangguan" value="{{ $jenisGangguan->jenis_gangguan_name }}">
                                    @if ($errors->has('jenis_gangguan_name'))
                                        <h6 class="text-red mt-2">{{ $errors->first('jenis_gangguan_name') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Community Concern</label>
                                    <input type="text" name="community_concern_value" class="form-control" placeholder="" value="{{ $jenisGangguan->community_concern_value }}">
                                    @if ($errors->has('community_concern_value'))
                                        <h6 class="text-red mt-2">{{ $errors->first('community_concern_value') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Prevalensi</label>
                                    <input type="text" name="prevalensi_value" class="form-control" placeholder="" value="{{ $jenisGangguan->prevalensi_value }}">
                                    @if ($errors->has('prevalensi_value'))
                                        <h6 class="text-red mt-2">{{ $errors->first('prevalensi_value') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Seriousness</label>
                                    <input type="text" name="seriousness_value" class="form-control" placeholder="" value="{{ $jenisGangguan->seriousness_value }}">
                                    @if ($errors->has('seriousness_value'))
                                        <h6 class="text-red mt-2">{{ $errors->first('seriousness_value') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Manageability</label>
                                    <input type="text" name="manageability_value" class="form-control" placeholder="" value="{{ $jenisGangguan->manageability_value }}">
                                    @if ($errors->has('manageability_value'))
                                        <h6 class="text-red mt-2">{{ $errors->first('manageability_value') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <a href="{{ url('jenis-gangguan') }}" class="btn btn-danger notika-btn-danger"><i class="notika-icon notika-close"></i> Batal</a>
                                <button class="btn btn-success notika-btn-success"><i class="notika-icon notika-sent"></i> Simpan</button>
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>

@endsection