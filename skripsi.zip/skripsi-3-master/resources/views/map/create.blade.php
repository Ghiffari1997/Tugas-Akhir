@extends('main_layout')
@section('content')

<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-12 col-12">
                    @if(session('success') || session('error'))
                        @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                            <span class="alert-text"><strong>Success!</strong> T{{session('success')}}</span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif
        
                        @if(session('error'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                            <span class="alert-text"><strong>Error!</strong> T{{session('error')}}</span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mt--6">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <h3 class="mb-0">Form upload map.</h3>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    {!! Form::open(['route' => 'map-review.store', 'method' => 'post', 'enctype' => 'multipart/form-data']) !!}
                        <div class="row">
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Keterangan</label>
                                    <input name="map_review_name" class="form-control" value="{{ old('map_review_name') }}">
                                    @if ($errors->has('map_review_name'))
                                        <h6 class="text-red mt-2">{{ $errors->first('map_review_name') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-8 col-lg-8">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Upload Gambar</label>
                                    <input type="file" name="map_review_image" class="form-control" placeholder="Upload Gambar" value="{{ old('map_review_image') }}">
                                    @if ($errors->has('map_review_image'))
                                        <h6 class="text-red mt-2">{{ $errors->first('map_review_image') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <a href="{{ url('jenis-gangguan') }}" class="btn btn-danger notika-btn-danger"><i class="notika-icon notika-close"></i> Batal</a>
                                <button class="btn btn-success notika-btn-success"><i class="notika-icon notika-sent"></i> Simpan</button>
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>

@endsection