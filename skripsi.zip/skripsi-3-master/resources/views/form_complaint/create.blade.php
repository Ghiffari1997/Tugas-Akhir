@extends('main_layout')
@section('content')

<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-12 col-12">
                    @if(session('success') || session('error'))
                        @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                            <span class="alert-text"><strong>Success!</strong> T{{session('success')}}</span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif
        
                        @if(session('error'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                            <span class="alert-text"><strong>Error!</strong> T{{session('error')}}</span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

@if(strtoupper($user['role']['role_name']) != 'CUSTOMER')
<div class="container-fluid mt--6">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <h3 class="mb-0">Tambah Data Pelanggan</h3>
                            <p>
                                Apabila data tidak ditemukan pada kolom pencarian, silahkan isi data pelanggan pada form dengan input manual.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    {!! Form::open(['class' => 'search-customer']) !!}
                        <div class="row">
                            <div class="col-sm-8 col-md-8 col-lg-8">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">No. Internet</label>
                                    <input type="text" class="form-control" name="no_internet" id="no_internet">
                                    @if ($errors->has('ticket_user_id'))
                                        <h6 class="text-red mt-2">{{ $errors->first('ticket_user_id') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-4 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">&nbsp;</label>
                                    <button type="button" class="btn btn-success form-control" id="search-customer">Cari</button>
                                </div>
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endif

@if(strtoupper($user['role']['role_name']) == 'CUSTOMER')
<div class="container-fluid mt--6">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    {!! Form::open(['route' => 'form-komplain-pelanggan.store', 'method' => 'post']) !!}
                        <div class="row">
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Nama pelanggan</label>
                                    <input type="text" class="form-control" name="customer_name" id="customer_name" value="{{ $customer->customer_name }}">
                                    @if ($errors->has('customer_name'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_name') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Email pelanggan</label>
                                    <input type="text" class="form-control" name="customer_email" id="customer_email" value="{{ $customer->customer_email }}">
                                    @if ($errors->has('customer_email'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_email') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">No. Internet</label>
                                    <input type="text" class="form-control" name="customer_internet_id" id="customer_internet_id" value="{{ $customer->customer_internet_id }}">
                                    @if ($errors->has('customer_internet_id'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_internet_id') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">No. Telp</label>
                                    <input type="text" class="form-control" name="customer_phone_number" id="customer_phone_number" value="{{ $customer->customer_phone_number }}">
                                    @if ($errors->has('customer_phone_number'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_phone_number') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">No. Handphone</label>
                                    <input type="text" class="form-control" name="customer_addtional_info" id="customer_addtional_info" value="{{ $customer->customer_addtional_info }}">
                                    @if ($errors->has('customer_addtional_info'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_addtional_info') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Alamat pelanggan</label>
                                    <textarea type="text" class="form-control" name="customer_address" id="customer_address">{{ $customer->customer_address }}</textarea>
                                    @if ($errors->has('customer_address'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_address') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Kategori Gangguan</label>
                                    <select name="kategori_gangguan_id" class="form-control" id="kategori_gangguan_id">
                                        <option value="">Silahkan Pilih Kategori angguan</option>
                                        @foreach($kategori as $item)
                                            <option value="{{ $item->kategori_gangguan_id }}">{{ $item->kategori_gangguan_name }}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('ticket_user_id'))
                                        <h6 class="text-red mt-2">{{ $errors->first('ticket_user_id') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Jenis Gangguan</label>
                                    <div id="data_jenis_gangguan">
                                        
                                    </div>
                                    @if ($errors->has('ticket_user_id'))
                                        <h6 class="text-red mt-2">{{ $errors->first('ticket_user_id') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Detail Gangguan</label>
                                    <textarea type="text" class="form-control" name="detail_complain" id="customer_address">{{ old('detail_complain') }}</textarea>
                                    @if ($errors->has('detail_complain'))
                                        <h6 class="text-red mt-2">{{ $errors->first('detail_complain') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <a href="{{ url('data-komplain') }}" class="btn btn-danger notika-btn-danger"><i class="notika-icon notika-close"></i> Batal</a>
                                <button class="btn btn-success notika-btn-success"><i class="notika-icon notika-sent"></i> Simpan</button>
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@else
<div class="container-fluid mt-1">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    {!! Form::open(['route' => 'form-komplain-pelanggan.store', 'method' => 'post']) !!}
                        <div class="row">
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Nama pelanggan</label>
                                    <input type="text" class="form-control" name="customer_name" id="customer_name" value="{{ old('customer_name') }}">
                                    @if ($errors->has('customer_name'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_name') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Email pelanggan</label>
                                    <input type="text" class="form-control" name="customer_email" id="customer_email" value="{{ old('customer_email') }}">
                                    @if ($errors->has('customer_email'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_email') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">No. Internet</label>
                                    <input placeholder="Kosongkan apabila hanya pengguna Telefon" type="text" class="form-control" name="customer_internet_id" id="customer_internet_id" value="{{ old('customer_internet_id') }}">
                                    @if ($errors->has('customer_internet_id'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_internet_id') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">No. Telp</label>
                                    <input placeholder="Kosongkan apabila hanya pengguna internet" type="text" class="form-control" name="customer_phone_number" id="customer_phone_number" value="{{ old('customer_phone_number') }}">
                                    @if ($errors->has('customer_phone_number'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_phone_number') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">No. Handphone</label>
                                    <input type="text" class="form-control" name="customer_addtional_info" id="customer_addtional_info" value="{{ old('customer_addtional_info') }}">
                                    @if ($errors->has('customer_addtional_info'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_addtional_info') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Alamat pelanggan</label>
                                    <textarea type="text" class="form-control" name="customer_address" id="customer_address">{{ old('customer_address') }}</textarea>
                                    @if ($errors->has('customer_address'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_address') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Teknisi</label>
                                    <select name="customer_user_id" class="form-control">
                                        <option value="">Silahkan Pilih Teknisi</option>
                                        @foreach($users as $item)
                                            <option value="{{ $item->id }}">{{ $item->name }}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('customer_user_id'))
                                        <h6 class="text-red mt-2">{{ $errors->first('customer_user_id') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Kategori Gangguan</label>
                                    <select name="kategori_gangguan_id" class="form-control" id="kategori_gangguan_id">
                                        <option value="">Silahkan Pilih Kategori angguan</option>
                                        @foreach($kategori as $item)
                                            <option value="{{ $item->kategori_gangguan_id }}">{{ $item->kategori_gangguan_name }}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('ticket_user_id'))
                                        <h6 class="text-red mt-2">{{ $errors->first('ticket_user_id') }}</h6>
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Jenis Gangguan</label>
                                    <div id="data_jenis_gangguan">
                                        
                                    </div>
                                    @if ($errors->has('ticket_user_id'))
                                        <h6 class="text-red mt-2">{{ $errors->first('ticket_user_id') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Detail Gangguan</label>
                                    <textarea type="text" class="form-control" name="detail_complain" id="customer_address">{{ old('detail_complain') }}</textarea>
                                    @if ($errors->has('detail_complain'))
                                        <h6 class="text-red mt-2">{{ $errors->first('detail_complain') }}</h6>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <a href="{{ url('data-komplain') }}" class="btn btn-danger notika-btn-danger"><i class="notika-icon notika-close"></i> Batal</a>
                                <button class="btn btn-success notika-btn-success"><i class="notika-icon notika-sent"></i> Simpan</button>
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endif

@endsection

@section('scripts')
    <script>
        $("#search-customer").click(function() {
            var param = $("#no_internet").val();
            $.ajax({
                url: globalUri+'/get-customer',
                data: { param: param},
                method: 'post',
                success: function(result){
                    if (result.code == 200)
                    {
                        var customer = result.data;
                        $("#customer_id").val(customer.customer_id)
                        $("#customer_name").val(customer.customer_name)
                        $("#customer_internet_id").val(customer.customer_internet_id)
                        $("#customer_phone_number").val(customer.customer_phone_number)
                        $("#customer_additional_info").val(customer.customer_additional_info)
                        $("#customer_address").val(customer.customer_address)
                        $("#customer_email").val(customer.customer_email)
                    } 
                    else 
                    {
                        alert('tidak ada data ditemukan');
                    }
                }
            });
        });

        $("#kategori_gangguan_id").change(function() {
            var kategori_gangguan_id = $(this).val();
            $("#data_jenis_gangguan").html("");
            $.ajax({
                url: globalUri+'/get-jenis-gangguan',
                data: { kategori_gangguan_id: kategori_gangguan_id},
                method: 'post',
                success: function(result){
                    if (result.code == 200)
                    {
                        var data = result.data;
                        console.log(data);
                        var html = '<select name="jenis_gangguan_id" class="form-control">';
                                    for(var i=0; i<data.length; i++)
                                    {
                                        html +=
                                        '<option value="'+data[i].jenis_gangguan_id+'">'+data[i].jenis_gangguan_name+'</option>';
                                    }
                                    html +=
                                    '</select>';
                        $("#data_jenis_gangguan").html(html);
                    } 
                    else 
                    {
                        $("#data_jenis_gangguan").html("");
                        alert('tidak ada data ditemukan');
                    }
                }
            });
        });
    </script>
@endsection