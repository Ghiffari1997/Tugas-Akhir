<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'Auth\LoginController@index');
Route::get('login', 'Auth\LoginController@login')->name('login');
Route::post('doLogin', 'Auth\LoginController@doLogin')->name('doLogin');
Route::get('logout', 'Auth\LoginController@logout')->name('logout');
Route::get('register', 'Auth\LoginController@register');
Route::get('do-register', 'Auth\LoginController@doRegister')->name('doRegister');
Route::get('home', 'HomeController@index')->name('home');

// USER
Route::get('user/edit/{id}', 'UserController@edit');
Route::get('user/delete/{id}', 'UserController@destroy');
Route::get('user', 'UserController@index')->name('user');
Route::get('add-user', 'UserController@create');
Route::resource('user', 'UserController');

// ROLE
Route::get('role/edit/{id}', 'RoleController@edit');
Route::get('role/delete/{id}', 'RoleController@destroy');
Route::get('role', 'RoleController@index')->name('role');
Route::get('add-role', 'RoleController@create');
Route::get('role/access/{id}', 'RoleController@access');
Route::get('role/action/{id}', 'RoleController@action');
Route::post('addAccess', 'RoleController@addAccess')->name('addAccess');
Route::post('addAction', 'RoleController@addAction')->name('addAction');
Route::resource('role', 'RoleController');

// POLI
Route::get('kategori-gangguan/edit/{id}', 'DistruptionCategoryController@edit');
Route::get('kategori-gangguan/delete/{id}', 'DistruptionCategoryController@destroy');
Route::get('kategori-gangguan', 'DistruptionCategoryController@index')->name('kategori-gangguan');
Route::get('add-kategori-gangguan', 'DistruptionCategoryController@create');
Route::resource('kategori-gangguan', 'DistruptionCategoryController');

Route::get('jenis-gangguan/edit/{id}', 'SubDistruptionCategoryController@edit');
Route::get('jenis-gangguan/delete/{id}', 'SubDistruptionCategoryController@destroy');
Route::get('jenis-gangguan', 'SubDistruptionCategoryController@index')->name('jenis-gangguan');
Route::get('add-jenis-gangguan', 'SubDistruptionCategoryController@create');
Route::resource('jenis-gangguan', 'SubDistruptionCategoryController');

Route::get('data-komplain/edit/{id}', 'DataComplaintController@edit');
Route::get('data-komplain', 'DataComplaintController@index')->name('data-komplain');
Route::get('add-data-komplain', 'DataComplaintController@create');
Route::resource('data-komplain', 'DataComplaintController');

Route::get('form-komplain-pelanggan/edit/{id}', 'FormComplaintController@edit');
Route::get('form-komplain-pelanggan', 'FormComplaintController@index')->name('form-komplain-pelanggan');
Route::get('add-form-komplain-pelanggan', 'FormComplaintController@create');
Route::resource('form-komplain-pelanggan', 'FormComplaintController');
Route::post('get-customer', 'FormComplaintController@getCustomer');
Route::post('get-jenis-gangguan', 'FormComplaintController@getJenisGangguan');

Route::get('edit-profile/edit/{id}', 'CustomerController@editProfile');
Route::get('data-customer', 'CustomerController@index')->name('data-customer');
Route::resource('data-customer', 'CustomerController');

Route::get('report-komplain', 'DataComplaintController@report');
Route::post('report-komplain/filter', 'DataComplaintController@filter');

Route::get('map-review', 'MapController@index');
Route::get('map-review/add', 'MapController@add');
Route::get('map-review/delete/{id}', 'MapController@delete');
Route::get('map-review/detail/{id}', 'MapController@detail');
Route::resource('map-review', 'MapController');