<?php

return [
    'REDIS_ACCESS' => 'user_access_',
    'IMAGE_PATH' => '/Users/arak/Documents/MY DOCS/WEB/TA/skripsi-3/public/assets/img/'
];